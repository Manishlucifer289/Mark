package com.mark.mark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MarkApplicationTests {

	@Test
	void contextLoads() {
	}

}
