package com.mark.mark;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MarkApplication {

	public static void main(String[] args) {
		SpringApplication.run(MarkApplication.class, args);
	}

}
